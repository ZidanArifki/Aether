// Firebase Config
const firebaseConfig = {
  apiKey: "AIzaSyAoe8rNw_Ti-StzB0ERzdsGpJ1CKjmiEMU",
  authDomain: "aether-sovereign.firebaseapp.com",
  projectId: "aether-sovereign",
  storageBucket: "aether-sovereign.firebasestorage.app",
  messagingSenderId: "461248328418",
  appId: "1:461248328418:web:1d767ddb136c2f6f7464bb",
  measurementId: "G-X7LBQST23N"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

const auth = firebase.auth();
const db = firebase.firestore();

async function uploadBase(){

    const title =
    document.getElementById("title").value;

    const category =
    document.getElementById("category").value;

    const layoutLink =
    document.getElementById("layoutLink").value;

    const imageFile =
    document.getElementById("imageFile").value;

    try{

        await db.collection("bases").add({

            title: title,

            category: category,

            layoutLink: layoutLink,

            imageUrl: "images/" + imageFile,

            createdAt: new Date()

        });

        alert("Base uploaded!");

    }

    catch(error){

        alert(error.message);

    }

}

// Login Function
function login(){

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    auth.signInWithEmailAndPassword(email, password)

    .then(() => {

        window.location.href = "dashboard.html";

    })

    .catch((error) => {

        document.getElementById("status").innerText =
        error.message;

    });

}
// Logout
function logout(){

    auth.signOut()

    .then(() => {

        window.location.href = "login.html";

    });

}
// Protect Dashboard
auth.onAuthStateChanged((user) => {

    if(
        !user &&
        window.location.pathname.includes("dashboard.html")
    ){

        window.location.href = "login.html";

    }

});
async function uploadBase(){

    const title =
    document.getElementById("title").value;

    const category =
    document.getElementById("category").value;

    const layoutLink =
    document.getElementById("layoutLink").value;

    const imageFile =
    document.getElementById("imageFile").files[0];

    if(!imageFile){
        alert("Select image first");
        return;
    }

    try{

        // Upload image
        const storageRef =
        storage.ref("bases/" + imageFile.name);

        await storageRef.put(imageFile);

        const imageUrl =
        await storageRef.getDownloadURL();

        // Save database
        await db.collection("bases").add({

            title: title,

            category: category,

            layoutLink: layoutLink,

            imageUrl: imageUrl,

            createdAt: new Date()

        });

        alert("Base uploaded!");

    }

    catch(error){

        alert(error.message);

    }

}